package org.ch02.test;

import com.sun.rowset.internal.Row;
import org.apache.ibatis.session.RowBounds;
import org.ch02.dao.StuDao;
import org.ch02.dao.impl.StuDaoImpl;
import org.ch02.entity.Students;
import org.junit.Test;

import java.util.List;
import java.util.Map;

/**
 * Created by wangl on 2017/3/21.
 */
public class StuTest {

    @Test
    public void test(){
        StuDao dao = new StuDaoImpl();
        RowBounds rowBounds = new RowBounds(0,2);
        List<Students> list = dao.findStuForEntityList(rowBounds);
        for (Students s : list) {
            System.out.println(s.getStuName());
        }

    }
}
