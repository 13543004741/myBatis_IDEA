package org.ch02.dao.impl;

import org.apache.ibatis.session.RowBounds;
import org.apache.ibatis.session.SqlSession;
import org.ch02.dao.StuDao;
import org.ch02.entity.Students;
import org.ch02.utils.MybatisUtil;

import java.util.List;
import java.util.Map;

/**
 * Created by wangl on 2017/3/21.
 */
public class StuDaoImpl implements StuDao{

    @Override
    public List<Students> findStuForEntityList() {
        SqlSession sqlSession = MybatisUtil.getSession();
        List<Students> list = null;
        try{
            list = sqlSession.getMapper(StuDao.class).findStuForEntityList();
        }finally {
            sqlSession.close();
        }
        return list;
    }

    @Override
    public List<Students> findStuForEntityList(RowBounds rowBounds) {
        SqlSession sqlSession = MybatisUtil.getSession();
        List<Students> list = null;
        try{
            list = sqlSession.getMapper(StuDao.class).findStuForEntityList(rowBounds);
        }finally {
            sqlSession.close();
        }
        return list;
    }


    @Override
    public List<Map<String, Object>> findStuForMapList() {
        SqlSession sqlSession = MybatisUtil.getSession();
        List<Map<String, Object>> list = null;
        try{
            list = sqlSession.getMapper(StuDao.class).findStuForMapList();
        }finally{
            sqlSession.close();
        }
        return list;
    }

    @Override
    public int count() {
        SqlSession sqlSession = MybatisUtil.getSession();
        int count = 0;
        try{
            count = sqlSession.getMapper(StuDao.class).count();
        }finally{
            sqlSession.close();
        }
        return count;
    }
}
