package org.ch02.dao;

import org.apache.ibatis.session.RowBounds;
import org.ch02.entity.Students;

import java.util.List;
import java.util.Map;

/**
 * Created by wangl on 2017/3/21.
 */
public interface StuDao {

    /**
     * 查询所有学员信息，返回list集合
     * 一个实体代表一条记录
     * @return
     */
    public List<Students> findStuForEntityList();

    /**
     * 分页查询,使用Mybatis提供的RowBounds
     * 在调用此方法时，创建一个RowBounds实例，指定其实记录和最大抓取条目
     * 并传递到该方法即可
     * 例如：
     * RowBounds rowBounds = new RowBounds(0,2);
     * sqlSession.getMapper(StuDao.class).findStuForEntityList(rowBounds);
     */
    public List<Students> findStuForEntityList(RowBounds rowBounds);

    /**
     * 查询所有学员信息，返回list集合，list中存放的是Map对象
     * 一个Map就代表一条记录
     */
    public List<Map<String, Object>> findStuForMapList();

    /**
     * 统计总记录数,返回的是一个int类型
     */
    public int count();
}
