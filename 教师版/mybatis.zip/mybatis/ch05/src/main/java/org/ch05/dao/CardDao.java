package org.ch05.dao;

import org.ch05.entity.StuCard;

/**
 * Created by wangl on 2017/3/23.
 */
public interface CardDao {

    public StuCard findCardById(int cid);

}
