package org.ch05.dao;

import org.ch05.entity.Students;

/**
 * Created by wangl on 2017/3/23.
 */
public interface StuDao {

    public Students findStuById(int sid);

    public Students findStuById2(int sid);

    public Students findStuById3(int sid);
}
