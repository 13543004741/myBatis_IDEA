package org.ch05.dao.impl;

import org.apache.ibatis.session.SqlSession;
import org.ch05.dao.CardDao;
import org.ch05.entity.StuCard;
import org.ch05.utils.MyBatisUtil;

/**
 * Created by wangl on 2017/3/23.
 */
public class CardDaoImpl implements CardDao{

    @Override
    public StuCard findCardById(int cid) {
        SqlSession sqlSession = MyBatisUtil.getSession();
        StuCard card = null;
        try{
            card = sqlSession.getMapper(CardDao.class).findCardById(cid);
        }finally{
            sqlSession.close();
        }
        return card;
    }
}
