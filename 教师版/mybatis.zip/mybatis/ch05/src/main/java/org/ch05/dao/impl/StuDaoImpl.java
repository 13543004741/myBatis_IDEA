package org.ch05.dao.impl;

import org.apache.ibatis.session.SqlSession;
import org.ch05.dao.StuDao;
import org.ch05.entity.Students;
import org.ch05.utils.MyBatisUtil;

/**
 * Created by wangl on 2017/3/23.
 */
public class StuDaoImpl implements StuDao{

    @Override
    public Students findStuById(int sid) {
        SqlSession sqlSession = MyBatisUtil.getSession();
        Students stu = null;
        try{
            stu = sqlSession.getMapper(StuDao.class).findStuById(sid);
        }finally{
            sqlSession.close();
        }
        return stu;
    }

    @Override
    public Students findStuById2(int sid) {
        SqlSession sqlSession = MyBatisUtil.getSession();
        Students stu = null;
        try{
            stu = sqlSession.getMapper(StuDao.class).findStuById2(sid);
        }finally{
            sqlSession.close();
        }
        return stu;
    }

    @Override
    public Students findStuById3(int sid) {
        SqlSession sqlSession = MyBatisUtil.getSession();
        Students stu = null;
        try{
            stu = sqlSession.getMapper(StuDao.class).findStuById3(sid);
        }finally{
            sqlSession.close();
        }
        return stu;
    }
}
