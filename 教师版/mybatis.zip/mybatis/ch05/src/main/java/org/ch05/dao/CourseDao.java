package org.ch05.dao;

import org.ch05.entity.Course;

import java.util.List;

/**
 * Created by wangl on 2017/3/23.
 */
public interface CourseDao {

    public List<Course> findCourses();
}
