package org.ch05.dao;

import org.ch05.entity.ClassInfo;

/**
 * Created by wangl on 2017/3/23.
 */
public interface ClassDao {

    public ClassInfo findClassById(int cid);

    public ClassInfo findClassById2(int cid);
}
