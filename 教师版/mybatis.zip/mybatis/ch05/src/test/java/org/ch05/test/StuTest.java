package org.ch05.test;

import org.ch05.dao.StuDao;
import org.ch05.dao.impl.StuDaoImpl;
import org.ch05.entity.Course;
import org.ch05.entity.Students;
import org.junit.Test;

/**
 * Created by wangl on 2017/3/23.
 */
public class StuTest {

    @Test
    public void test(){
        StuDao stuDao = new StuDaoImpl();
        Students s = stuDao.findStuById3(115);
        System.out.println(s.getStuName());
        System.out.println(s.getStuAge());
        for (Course c : s.getCourses()) {
            System.out.println(c.getCourseName());
        }
    }
}
