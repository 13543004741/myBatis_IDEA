package org.ch05.test;

import org.ch05.dao.ClassDao;
import org.ch05.dao.impl.ClassDaoImpl;
import org.ch05.entity.ClassInfo;
import org.ch05.entity.Course;
import org.ch05.entity.Students;
import org.junit.Test;

/**
 * Created by wangl on 2017/3/23.
 */
public class ClassTest {

    @Test
    public void test(){
        ClassDao dao = new ClassDaoImpl();
        ClassInfo classInfo = dao.findClassById(1);
        System.out.println(classInfo.getClassName());
        System.out.println();
        for (Students s: classInfo.getStudents()) {
            System.out.println(s.getStuName());
            /*for (Course c : s.getCourses()) {
                System.out.println(c.getCourseName());
            }
            System.out.println();*/
        }
    }
}
