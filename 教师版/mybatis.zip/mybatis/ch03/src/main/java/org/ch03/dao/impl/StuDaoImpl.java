package org.ch03.dao.impl;

import org.apache.ibatis.session.SqlSession;
import org.ch03.dao.StuDao;
import org.ch03.entity.Students;
import org.ch03.utils.MybatisUtil;

import java.util.List;

/**
 * Created by wangl on 2017/3/21.
 */
public class StuDaoImpl implements StuDao{


    @Override
    public Students findStuById(int id) {
        SqlSession sqlSession = MybatisUtil.getSession();
        Students stu = null;
        try{
            stu = sqlSession.getMapper(StuDao.class).findStuById(id);
        }finally{
            sqlSession.close();
        }
        return stu;
    }

    @Override
    public Students findStuByName(String stuName) {
        SqlSession sqlSession = MybatisUtil.getSession();
        Students stu = null;
        try{
            stu = sqlSession.getMapper(StuDao.class).findStuByName(stuName);
        }finally{
            sqlSession.close();
        }
        return stu;
    }

    @Override
    public Students findStudent(int id, String stuName) {
        SqlSession sqlSession = MybatisUtil.getSession();
        Students stu = null;
        try{
            stu = sqlSession.getMapper(StuDao.class).findStudent(id, stuName);
        }finally{
            sqlSession.close();
        }
        return stu;
    }

    @Override
    public Students findStudent2(Students stu) {
        SqlSession sqlSession = MybatisUtil.getSession();
        try{
            stu = sqlSession.getMapper(StuDao.class).findStudent2(stu);
        }finally{
            sqlSession.close();
        }
        return stu;
    }

    @Override
    public List<Students> likeStudents(String name) {
        SqlSession sqlSession = MybatisUtil.getSession();
        List<Students> list = null;
        try{
            list = sqlSession.getMapper(StuDao.class).likeStudents(name);
        }finally{
            sqlSession.close();
        }
        return list;
    }
}
