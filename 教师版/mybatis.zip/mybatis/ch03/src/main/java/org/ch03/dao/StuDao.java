package org.ch03.dao;

import org.ch03.entity.Students;

import java.util.List;

/**
 * Created by wangl on 2017/3/21.
 */
public interface StuDao {

    /**
     * 根据主键查询
     * @param id
     * @return
     */
    public Students findStuById(int id);

    /**
     * 根据名称查询
     * @param stuName
     * @return
     */
    public Students findStuByName(String stuName);

    /**
     * 根据id以及用户名查询
     */
    public Students findStudent(int id, String stuName);

    /**
     * 将查询参数封装到对象中
     * @param stu
     * @return
     */
    public Students findStudent2(Students stu);

    /**
     * 模糊查询
     * @param name
     * @return
     */
    public List<Students> likeStudents(String name);

}
