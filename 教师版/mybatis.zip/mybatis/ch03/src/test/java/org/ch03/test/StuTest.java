package org.ch03.test;

import org.ch03.dao.StuDao;
import org.ch03.dao.impl.StuDaoImpl;
import org.ch03.entity.Students;
import org.junit.Test;

import java.util.List;

/**
 * Created by wangl on 2017/3/21.
 */
public class StuTest {

    @Test
    public void test(){
        StuDao dao = new StuDaoImpl();

        List<Students> list = dao.likeStudents("ser");
        for (Students s : list) {
            System.out.println(s.getStuName());
        }

        /*Students stu = dao.findStuByName("user1");
        System.out.println(stu.getStuName());*/

        /*List<Students> list = dao.likeStudents("ser");
        for (Students s: list) {
            System.out.println(s.getStuName());
        }*/
    }
}
