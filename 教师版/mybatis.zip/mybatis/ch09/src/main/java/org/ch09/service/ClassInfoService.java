package org.ch09.service;

import org.ch09.entity.ClassInfo;

/**
 * Created by wangl on 2017/3/27.
 */
public interface ClassInfoService {

    public ClassInfo findClassInfoById(int cid);
}
