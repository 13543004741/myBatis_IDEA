package org.ch01.test;

import org.ch01.dao.StuDao;
import org.ch01.dao.impl.StuDaoImpl;
import org.ch01.entity.Students;
import org.junit.Test;

import java.util.List;
import java.util.Map;

/**
 * Created by wangl on 2017/3/20.
 */
public class StuTest {

    @Test
    public void test(){
        StuDao dao = new StuDaoImpl();

        Students stu = new Students();
        stu.setStuName("user6");
        stu.setStuAge(19);
        dao.save(stu);
        System.out.println(stu.getSid());

    }
}
