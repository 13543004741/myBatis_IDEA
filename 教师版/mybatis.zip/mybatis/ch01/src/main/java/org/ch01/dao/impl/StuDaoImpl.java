package org.ch01.dao.impl;

import org.apache.ibatis.session.SqlSession;
import org.ch01.dao.StuDao;
import org.ch01.entity.Students;
import org.ch01.utils.MybatisUtil;

/**
 * Created by wangl on 2017/3/20.
 */
public class StuDaoImpl implements StuDao{

    @Override
    public int save(Students student) {
        //获取一个SqlSession对象
        SqlSession sqlSession = MybatisUtil.getSqlSession();
        int row = 0;
        try{
            //通过sqlSession的getMapper方法指定映射的接口,然后调用接口相应的方法即可
            row = sqlSession.getMapper(StuDao.class).save(student);
            //如果sqlSession对象是通过SqlSessionFactory的openSession()方法获取的时候
            //那么得到的sqlSession必须手动提交事务
            //如果是通过openSession(true)这个方法获取的时候，那么事务是自动提交的
            sqlSession.commit();
        }catch(Exception e){
            e.printStackTrace();
            //回滚事务
            sqlSession.rollback();
        }finally {
            //关闭连接
            sqlSession.close();
        }
        return row;
    }

    @Override
    public int delete(int sid) {
        SqlSession sqlSession = MybatisUtil.getSqlSession();
        int row = 0;
        try{
            row = sqlSession.getMapper(StuDao.class).delete(sid);
            sqlSession.commit();
        }catch(Exception e){
            e.printStackTrace();
            sqlSession.rollback();
        }finally{
            sqlSession.close();
        }
        return row;
    }

    @Override
    public int update(Students student) {
        SqlSession sqlSession = MybatisUtil.getSqlSession();
        int row = 0;
        try{
            row = sqlSession.getMapper(StuDao.class).update(student);
            sqlSession.commit();
        }catch(Exception e){
            e.printStackTrace();
            sqlSession.rollback();
        }finally {
            sqlSession.close();
        }
        return row;
    }
}
