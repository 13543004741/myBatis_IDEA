package org.ch01.dao;

import org.ch01.entity.Students;

/**
 * Created by wangl on 2017/3/20.
 * Dao接口，其实这个接口也就是mybatis的要映射的mapper
 * 每一个mapper.xml文件都会对应一个接口，映射文件中的每条
 * sql语句就对应接口中的某个方法，这是一一对应的
 */
public interface StuDao {

    /**
     * 添加
     * @param student
     * @return
     */
    public int save(Students student);

    /**
     * 删除
     * @param sid
     * @return
     */
    public int delete(int sid);

    /**
     * 修改
     * @param student
     * @return
     */
    public int update(Students student);

}
