package org.ch04.test;

import org.ch04.dao.StuDao;
import org.ch04.dao.impl.StuDaoImpl;
import org.ch04.entity.Students;
import org.junit.Test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by wangl on 2017/3/22.
 */
public class StuTest {

    @Test
    public void test(){
        StuDao dao = new StuDaoImpl();
        //封装查询条件
        Map<String, Object> map = new HashMap<>();
        map.put("name","user11");
        map.put("sid", 115);
        int i = dao.update(map);
        System.out.println(i);
    }
}
