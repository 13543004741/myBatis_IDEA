package org.ch09.test;

import org.ch09.dao.CardDao;
import org.ch09.dao.impl.CardDaoImpl;
import org.ch09.entity.StuCard;
import org.junit.Test;

/**
 * Created by wangl on 2017/3/27.
 */
public class CardTest {

    @Test
    public void test(){
        CardDao dao = new CardDaoImpl();
        StuCard card = dao.findCardById(1);
        System.out.println(card.getStudent().getStuName());
        System.out.println(card.getCardNum());
    }
}
