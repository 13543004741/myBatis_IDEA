package org.ch09.test;

import org.ch09.dao.CourseDao;
import org.ch09.dao.impl.CourseDaoImpl;
import org.ch09.entity.Course;
import org.junit.Test;

import java.util.List;

/**
 * Created by wangl on 2017/3/27.
 */
public class CourseTest {

    @Test
    public void test(){
        CourseDao dao = new CourseDaoImpl();
        List<Course> list = dao.findCourses();
        for (Course c : list) {
            System.out.println(c.getCourseName());
        }
    }
}
