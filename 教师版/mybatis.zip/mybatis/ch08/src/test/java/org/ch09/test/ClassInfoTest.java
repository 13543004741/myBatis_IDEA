package org.ch09.test;

import org.ch09.dao.ClassDao;
import org.ch09.dao.impl.ClassDaoImpl;
import org.ch09.entity.ClassInfo;
import org.ch09.entity.Course;
import org.ch09.entity.Students;
import org.junit.Test;

/**
 * Created by wangl on 2017/3/27.
 */
public class ClassInfoTest {

    @Test
    public void test(){
        ClassDao dao = new ClassDaoImpl();
        ClassInfo cla = dao.findClassById2(1);
        System.out.println(cla.getClassName());
        for (Students s: cla.getStudents()) {
            System.out.println(s.getStuName());
            for (Course c : s.getCourses()) {
                System.out.println(c.getCourseName());
            }
            System.out.println();
        }
    }
}
