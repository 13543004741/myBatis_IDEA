package org.ch09.test;

import org.ch09.dao.StuDao;
import org.ch09.dao.impl.StuDaoImpl;
import org.ch09.entity.Course;
import org.ch09.entity.Students;
import org.junit.Test;

/**
 * Created by wangl on 2017/3/27.
 */
public class StuTest {

    @Test
    public void test(){
        StuDao dao = new StuDaoImpl();
        Students s = dao.findStuById3(115);
        System.out.println(s.getStuName());
        for (Course c : s.getCourses()) {
            System.out.println(c.getCourseName());
        }
    }
}
