package org.ch09.dao.impl;

import org.apache.ibatis.session.SqlSession;
import org.ch09.dao.CardDao;
import org.ch09.entity.StuCard;
import org.ch09.utils.MyBatisUtil;

/**
 * Created by wangl on 2017/3/23.
 */
public class CardDaoImpl implements CardDao{

    @Override
    public StuCard findCardById(int cid) {
        SqlSession sqlSession = MyBatisUtil.getSession();
        StuCard card = null;
        try{
            card = sqlSession.getMapper(CardDao.class).findCardById(cid);
        }finally{
            sqlSession.close();
        }
        return card;
    }
}
