package org.ch09.dao;

import org.apache.ibatis.annotations.ResultMap;
import org.apache.ibatis.annotations.Select;
import org.ch09.entity.Course;

import java.util.List;

/**
 * Created by wangl on 2017/3/23.
 */
public interface CourseDao {

    //查询所有课程信息
    @Select("SELECT * FROM COURSE")
    @ResultMap("org.ch08.dao.CourseDao.courseMap")
    public List<Course> findCourses();
}
