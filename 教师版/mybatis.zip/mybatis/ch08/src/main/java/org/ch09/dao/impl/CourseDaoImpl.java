package org.ch09.dao.impl;

import org.apache.ibatis.session.SqlSession;
import org.ch09.dao.CourseDao;
import org.ch09.entity.Course;
import org.ch09.utils.MyBatisUtil;

import java.util.List;

/**
 * Created by wangl on 2017/3/23.
 */
public class CourseDaoImpl implements CourseDao{

    @Override
    public List<Course> findCourses() {
        SqlSession sqlSession = MyBatisUtil.getSession();
        List<Course> list = null;
        try{
            list = sqlSession.getMapper(CourseDao.class).findCourses();
        }finally{
            sqlSession.close();
        }
        return list;
    }
}
