package org.ch06.dao.impl;

import org.apache.ibatis.session.SqlSession;
import org.ch06.dao.StuDao;
import org.ch06.entity.Students;
import org.ch06.utils.MyBatisUtil;

import java.util.List;
import java.util.Map;

/**
 * Created by wangl on 2017/3/24.
 */
public class StuDaoImpl implements StuDao{

    @Override
    public int save(Students stu) {
        SqlSession sqlSession = MyBatisUtil.getSession();
        int i = 0;
        try{
            i = sqlSession.getMapper(StuDao.class).save(stu);
            sqlSession.commit();
        }catch(Exception e){
            e.printStackTrace();
            sqlSession.rollback();
        }finally {
            sqlSession.close();
        }
        return i;
    }

    @Override
    public int delete(int sid) {
        SqlSession sqlSession = MyBatisUtil.getSession();
        int i = 0;
        try{
            i = sqlSession.getMapper(StuDao.class).delete(sid);
            sqlSession.commit();
        }catch(Exception e){
            e.printStackTrace();
            sqlSession.rollback();
        }finally {
            sqlSession.close();
        }
        return i;
    }

    @Override
    public int update(Students stu) {
        SqlSession sqlSession = MyBatisUtil.getSession();
        int i = 0;
        try{
            i = sqlSession.getMapper(StuDao.class).update(stu);
            sqlSession.commit();
        }catch(Exception e){
            e.printStackTrace();
            sqlSession.rollback();
        }finally {
            sqlSession.close();
        }
        return i;
    }

    @Override
    public List<Students> findStudentsForEntity() {
        SqlSession sqlSession = MyBatisUtil.getSession();
        List<Students> list = null;
        try{
            list = sqlSession.getMapper(StuDao.class).findStudentsForEntity();
        }finally{
            sqlSession.close();
        }
        return list;
    }

    @Override
    public List<Map<String, Object>> findStudentsForMap() {
        SqlSession sqlSession = MyBatisUtil.getSession();
        List<Map<String, Object>> list = null;
        try{
            list = sqlSession.getMapper(StuDao.class).findStudentsForMap();
        }finally{
            sqlSession.close();
        }
        return list;
    }

    @Override
    public Students findStuById(int sid) {
        SqlSession sqlSession = MyBatisUtil.getSession();
        Students stu = null;
        try{
            stu = sqlSession.getMapper(StuDao.class).findStuById(sid);
        }finally{
            sqlSession.close();
        }
        return stu;
    }

    @Override
    public Students findStuByCondition(String stuName, int age) {
        SqlSession sqlSession = MyBatisUtil.getSession();
        Students stu = null;
        try{
            stu = sqlSession.getMapper(StuDao.class).findStuByCondition(stuName, age);
        }finally{
            sqlSession.close();
        }
        return stu;
    }

    @Override
    public Students findStuByCondition2(Students stu) {
        SqlSession sqlSession = MyBatisUtil.getSession();
        try{
            stu = sqlSession.getMapper(StuDao.class).findStuByCondition2(stu);
        }finally{
            sqlSession.close();
        }
        return stu;
    }
}
