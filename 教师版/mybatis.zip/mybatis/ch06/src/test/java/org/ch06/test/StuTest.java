package org.ch06.test;

import org.ch06.dao.StuDao;
import org.ch06.dao.impl.StuDaoImpl;
import org.ch06.entity.Students;
import org.junit.Test;

import java.util.List;
import java.util.Map;

/**
 * Created by wangl on 2017/3/24.
 */
public class StuTest {

    @Test
    public void test(){
        StuDao dao = new StuDaoImpl();
        Students stu = dao.findStuByCondition("user1", 19);
        System.out.println(stu.getStuName());
        System.out.println(stu.getStuAge());

        /*Students stu = new Students();
        stu.setStuName("user1");
        stu.setStuAge(19);
        stu = dao.findStuByCondition2(stu);
        System.out.println(stu.getSid());
        System.out.println(stu.getStuName());
        System.out.println(stu.getStuAge());*/
    }
}
