package org.ch07.test;

import org.ch07.dao.StuDao;
import org.ch07.dao.impl.StuDaoImpl;
import org.ch07.entity.Students;
import org.junit.Test;

import java.util.List;

/**
 * Created by wangl on 2017/3/24.
 */
public class StuTest {

    @Test
    public void test(){
        StuDao dao = new StuDaoImpl();
        Students stu = new Students();
        //stu.setStuName("user1");
        List<Students> list  = dao.findStuByCondition2(stu);
        for (Students s: list) {
            System.out.println(s.getStuName());
        }

    }
}
