package org.ch07.provider;

import org.apache.ibatis.jdbc.SQL;
import org.ch07.entity.Students;

/**
 * Created by wangl on 2017/3/24.
 * 自定义一个类，这个类就是一个Sql提供方,
 * 用于定义接口中各种方法的SQL语句
 *
 * MyBatis提供了一个SQL类来封装sql语句
 */
public class StuDaoSqlProvider {

    //返回值必须是String，因为sql语句就是一个字符串类型
    public String findStuByIdSql(){
        return new SQL(){
            {
                SELECT("STU_ID AS sid, STU_NAME AS stuName, STU_AGE AS stuAge");
                FROM("STUDENTS");
                WHERE("STU_ID = #{id}");
            }
        }.toString();
    }

    /**
     * 多参数查询
     * @return
     */
    public String findStuByConditionSql(){
        return new SQL(){
            {
                SELECT("STU_ID AS sid, STU_NAME AS stuName, STU_AGE AS stuAge");
                FROM("STUDENTS");
                WHERE("STU_NAME = #{name}");
                //WHERE方法可以多次使用，mybatis会自动拼接and条件
                WHERE("STU_AGE = #{age}");
            }
        }.toString();
    }

    /**
     * 动态条件查询
     * provider类中的方法都可以定义参数，但是，参数的类型只能有两种
     * 一种是和Dao接口中相同类型的参数，另外一种只能是Map类型的参数
     * 当执行的时候，就会把Dao接口对应的参数传入这个provider的方法中
     *
     * 注意：如果使用map类型的参数，map的key是param1，param2，...这样的键
     * @return
     */
    public String findStuByConditionSql2(Students s){
        return new SQL(){
            {
                SELECT("STU_ID AS sid, STU_NAME AS stuName, STU_AGE AS stuAge");
                FROM("STUDENTS");
                if(s != null){
                    if(s.getStuName() != null){
                        WHERE("STU_NAME = #{stuName}");
                    }
                    if(s.getStuAge() != 0){
                        WHERE("STU_AGE = #{stuAge}");
                    }
                }
                ORDER_BY("STU_ID DESC");
            }
        }.toString();
    }

    /**
     * 添加操作
     * @return
     */
    public String saveSql(){
        return new SQL(){
            {
                INSERT_INTO("STUDENTS");
                //VALUES()方法也可以重复使用多次，表示插入多个列
                VALUES("STU_NAME", "#{stuName}");
                VALUES("STU_AGE", "#{stuAge}");
            }
        }.toString();
    }

    /**
     * 修改操作
     * @return
     */
    public String updateSql(){
        return new SQL(){
            {
                UPDATE("STUDENTS");
                SET("STU_NAME = #{stuName}");
                SET("STU_AGE = #{stuAge}");
                WHERE("STU_ID = #{sid}");
            }
        }.toString();
    }

    /**
     * 删除操作
     * @return
     */
    public String deleteSql(){
        return new SQL(){
            {
                DELETE_FROM("STUDENTS");
                WHERE("STU_ID = #{sid}");
            }
        }.toString();
    }
}
